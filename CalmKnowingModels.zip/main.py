def linearSearchProduct(productList, targetproduct):
    indices = []
    for index, product in  enumerate(productList):
        if product ==  targetproduct:
            indices.append(index)

    return indices


products = ["apple", "banana", "strawberry", "orange", "grapes"]
target = "apple"
target2 = "Orange"
result = linearSearchProduct(products, target)
print(result )
