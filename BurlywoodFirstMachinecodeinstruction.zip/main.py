students = [
    Student("Tom", "A123", 7.8),
    Student("Jerry" , "A124", 8.9),
    Student("Jass", "A125", 9.1),
    Student("Joe",  "A126", 9.9),
]

sorted_students = 
sort_students(students)


for student in sorted_students:
  print("Name: {}, Roll Number: {}, CGPA:{}". format (student.name, student.roll_number, student.cgpa))
  